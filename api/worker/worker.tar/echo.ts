
function echo (payload) {
    return payload;
}

module.exports = echo;